BACKGROUND = "#121212"  
FONT =("Arial", 20)
COMPONENT = "#363636"
TEXT = "#84C9FB"

STYLE ={
    "font" : FONT,
    "bg" : COMPONENT,
    "fg" : TEXT
}