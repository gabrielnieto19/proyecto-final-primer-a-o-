MODES= {
    "NORMAL": "Normal",
    "ATREVIDO": "Atrevido",
    "HARDCORE": "Hardcore"
}