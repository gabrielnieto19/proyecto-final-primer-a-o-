
from multiprocessing.dummy import Manager

from Manager import Manager

if __name__ == "__main__":
    app = Manager()
    app.mainloop()